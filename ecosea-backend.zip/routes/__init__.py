from flask import Blueprint

auth_bp = Blueprint('auth', __name__)
laporan_bp = Blueprint('laporan', __name__)